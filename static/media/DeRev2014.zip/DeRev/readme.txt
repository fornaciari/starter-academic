DeRev - DEception in REViews corpus
By Tommaso Fornaciari and Massimo Poesio 

DeRev is made by 6819 reviews published on Amazon.com, concerning 68 different books.
Each review is represented by an xml file.
The files whose the name begins with 'F' and 'T' - for 'False' and 'True' - belong to the gold standard and contain false and true reviews, respectively.
The files with name starting by 'U' - for 'Uncertain' - do not belong to the gold standard.

Attributes of xml:
ID: the ID number of each review does not depend on the gold standard. It represents the progressive number of the reviews within the relative books which, in turn, were alphabetically sorted according to their title.
writer: the author of the book.
title: the title of the book.
author: the author of the review.
date: date of the review.
stars: number of stars given by the reviewer to the book.
fold: a number from 0 to 9, for 10-fold cross validation experiments.
suspectbook: clue of deception. Value 1 if present, 0 if absent.
cluster: clue of deception. Value 1 if present, 0 if absent.
nickname: clue of deception. Value 1 if present, 0 if absent.
unknownpurchase: clue of deception. Value 1 if present, 0 if absent.
sumclues: sum of the values of the deception clues.
allcluesclass: class obtained counting the presence of the four deception clues: 0, that is 'false', if 3 or 4 clues of deception are present; 1, that is 'true', if only 0, 1 or 2 clues of deception are found.
threecluesclass: class obtained removing the clue 'suspectbook'. 0 if 2 o 3 clues of deception are present; 1, if only 0 or 1 clue of deception is found.
realclass: gold standard class: 0 for false, 1 for true and 2 for the other reviews.

Citation:
For any use of DeRev, please cite:
@InProceedings{fornaciari-poesio:2014:EACL,
	author    = {Fornaciari, Tommaso  and  Poesio, Massimo},
	title     = {Identifying fake Amazon reviews as learning from crowds},
	booktitle = {Proceedings of the 14th Conference of the European Chapter of the Association for Computational Linguistics},
	month     = {April},
	year      = {2014},
	address   = {Gothenburg, Sweden},
	publisher = {Association for Computational Linguistics},
	pages     = {279--287},
	url       = {http://www.aclweb.org/anthology/E14-1030}
}



